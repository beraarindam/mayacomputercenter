
<?php $__env->startSection('title', 'Result List'); ?>
<?php $__env->startPush('custom-css'); ?>
	<style type="text/css">
		
	</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header bg-secondary text-white font-weight-bold">
					Result List
					
				</div>
			<div class="card-body">
				<div class="card-body">
				    <table id="datatable-buttons" class="table table-bordered table-sm table-striped w-100">
				        <thead>
					        <tr class="table_main_row">
					        	<th>#ID</th>
					        	<th>Reg.No</th>
					        	<th>Student Name</th>
					            <th>Percentage</th>
					            <th>Grade</th>
					            <th>Action</th>
					        </tr>
				        </thead>
				        <tbody>
				        	<?php $i=1; ?>
				        	<?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				        		<tr>
				        			<td><?php echo e($i++); ?></td>
				        			<td><?php echo e($data->sl_reg_no); ?></td>
				        			<td><?php echo e($data->sl_name); ?></td>
				        			<td><?php echo e($data->sr_percentage); ?>%</td>
				        			<td><?php echo e($data->sr_grade); ?></td>
				        			<td>
				        				<a href="<?php echo e(route('edit_result', $data->sl_id)); ?>" title="Edit Result" class="btn btn-primary btn-sm"><i class="fa-solid fa-pencil"></i></a>
				        				<a href="<?php echo e(route('generatePDF',$data->sr_id)); ?>" class="btn btn-info btn-sm" target="__blank" title="View Marksheet"><i class="fa-solid fa-eye"></i></a>
				        				
				        			</td>
				        		</tr>
				        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('center.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\mayacomputercentre\resources\views/center/result/index.blade.php ENDPATH**/ ?>
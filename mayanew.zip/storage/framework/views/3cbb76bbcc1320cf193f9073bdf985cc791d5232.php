
<?php $__env->startSection('title', 'Payment History'); ?>
<?php $__env->startPush('custom-css'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <h4 class="mb-0 font-size-18">YOUR LAST PAYMENT DETAILS</h4>
                    <div class="page-title-right">
                        <!-- You can add filters or buttons here if needed -->
                    </div>
                </div>

                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered align-middle mb-0">
                            <thead class="table-light">
                                <tr>
                                    
                                    <th>Paid Date</th>
                                    <th>Total</th>
                                    <th>Paid Amount</th>
                                    <th>Remarks</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $payment_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        
                                        <td><?php echo e($data->fp_date); ?></td>
                                        <td><?php echo e($data->fp_total_amount); ?></td>
                                        <td><?php echo e($data->fp_amount); ?></td>
                                        <td><?php echo e($data->fp_remarks); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div> <!-- end card-body -->
            </div> <!-- end card -->
        </div> <!-- end col -->
    </div> <!-- end row -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('student.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\mayacomputercentre\resources\views/student/view_payment_history.blade.php ENDPATH**/ ?>
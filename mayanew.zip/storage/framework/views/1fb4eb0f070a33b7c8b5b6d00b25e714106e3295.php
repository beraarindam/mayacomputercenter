
<?php $__env->startSection('title', 'Generate Admit Student'); ?>
<?php $__env->startPush('custom-css'); ?>
<style type="text/css">
		
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- start page title -->

<!-- end page title -->
<div class="row mt-3">
         <div class="col-lg-12">
            <div class="card">
            <div class="card-header bg-secondary text-white font-weight-bold">
                Admit Card Issue
            </div>
            <div class="card-body">
				<div class='row'>
				
					    
					    
				
					<div class='col-md-2'></div>
					<div class='col-md-4'>
					 <form action ='admit_card' method ='post' id='insert_frm'>
						<div class="form-group">
                          <label>Student Roll No(s) </label>  
							<textarea class="form-control" name='student_id' placeholder='911041010002,911041010006,910541010002'></textarea>
                        </div>
						
						<div class="form-group">
                          <label>Exam Date</label>   
							<input class="form-control" value='' name='exam_date' type='date' min=''>
                        </div>
						<div class="form-group">
                          <label>Exam Time</label>   
                            <input class="form-control" value='' name='exam_time' type='time' >
                        </div>
					</div>
					<div class='col-md-4'>
					    <div class="form-group">
                            <label class="control-label" >Select Set</label>
                            <select name ='set_id' class='form-select'>
                                                            </select>
                        </div>
                        
						<div class="form-group">
                            <label class="control-label" >Exam Venue</label>
                            <input type="text" class="form-control" name='exam_venue' required>
                        </div>
						
						<div class="form-group">
                            <label class="control-label" >Notice </label>
                            <input type="text" class="form-control" name='exam_notice' >
                        </div>
						
						
					</form>		
						<button class="btn btn-danger btn-block mt-2"  id='insert_btn' >Create Admit Card</button> 
					</div>
				</div>
		</div>
		</div>
		</div>
		</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('center.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\mayacomputercentre\resources\views/center/admit_card/create.blade.php ENDPATH**/ ?>
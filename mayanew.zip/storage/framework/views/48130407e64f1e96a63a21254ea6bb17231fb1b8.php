
<?php $__env->startSection('title', 'Add Course'); ?>
<?php $__env->startPush('custom-css'); ?>
<style type="text/css">
		
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<!-- start page title -->
<div class="row mt-3">
	<div class="col-12">
		<div class="page-title-box d-sm-flex align-items-center justify-content-between">
			<h4 class="mb-sm-0 font-size-18">Course</h4>
		</div>
	</div>
</div>
<!-- end page title -->
<div class="row">
	<div class="col-lg-6">
		<div class="card">
			<div class="card-header bg-secondary text-white font-weight-bold">
					Course Form
					<span class='float-right' style='float:right'>
						<a href="<?php echo e(route('course_list')); ?>">  <button class="btn btn-success btn-sm" >View All</button></a>
				</div>
			<div class="card-body">
				<form method="POST" enctype="multipart/form-data">
					<?php echo csrf_field(); ?>
					<div class="row">
						<div class="col-lg-12 mb-2">
							<div class="form-group">
								<label>Course Short Name</label>
								<input type="text" class="form-control" value="<?php echo e(old('course_short_name')); ?>" name="course_short_name" placeholder="Course Short Name">
								<?php $__errorArgs = ['course_short_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<p class="text-danger"><?php echo e($message); ?></p>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>
						<div class="col-lg-12 mb-2">
							<div class="form-group">
								<label>Course Full Name</label>
								<input type="text" class="form-control" value="<?php echo e(old('course_full_name')); ?>" name="course_full_name" placeholder="Course Full Name">
								<?php $__errorArgs = ['course_full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<p class="text-danger"><?php echo e($message); ?></p>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>
						<div class="col-lg-12 mb-2">
							<div class="form-group">
								<label>Course Price</label>
								<input type="text" class="form-control" value="<?php echo e(old('course_price')); ?>" name="course_price" placeholder="Course Price">
								<?php $__errorArgs = ['course_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<p class="text-danger"><?php echo e($message); ?></p>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>
						<div class="col-lg-12 mb-2">
							<div class="form-group">
								<label>Course Duration</label>
								<input type="text" class="form-control" value="<?php echo e(old('course_duration')); ?>" name="course_duration" placeholder="Course Duration">
								<?php $__errorArgs = ['course_duration'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
								<p class="text-danger"><?php echo e($message); ?></p>
								<?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
							</div>
						</div>
						<div class="col-lg-3"></div>
						<div class="col-lg-6">
							<button type="submit" class="btn w-100 btn-secondary custom-button "> <i class="fa fa-save"></i> Save</button>
						</div>
						<div class="col-lg-3 "></div>
					</div>
				</form>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\mayacomputercentre\resources\views/admin/course/create.blade.php ENDPATH**/ ?>
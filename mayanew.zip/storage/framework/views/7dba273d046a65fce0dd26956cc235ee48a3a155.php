
<?php $__env->startSection('title', 'Admit Card List'); ?>
<?php $__env->startPush('custom-css'); ?>
	<style type="text/css">
		
	</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header bg-secondary text-white font-weight-bold">
					Admit Card List
					<span class='float-right' style='float:right'>
						<a href="<?php echo e(route('generate_admit_card')); ?>">  <button class="btn btn-success btn-sm" >Generate New Admit</button></a>
				</div>
			<div class="card-body">
				<div class="card-body">
				    <table id="datatable-buttons" class="table table-bordered table-sm table-striped w-100">
				        <thead>
					        <tr class="table_main_row">
					        	<th>Reg.No</th>
					        	<th>Student Name</th>
					            <th>DOB</th>
					            <th>Exam Date</th>
					            <th>Venue</th>
					            <th>Time</th>
					            <th>Action</th>
					        </tr>
				        </thead>
				        <tbody>
				        	<?php $i=1; ?>
				        	
				        </tbody>
				    </table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('center.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\mayacomputercentre\resources\views/center/admit_card/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'View Transaction'); ?>
<?php $__env->startPush('custom-css'); ?>
<style type="text/css">
	
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>

<!-- end page title -->
<div class="card mb-4 mt-3">
	<div class="card-header bg-secondary text-white font-weight-bold">
		Transaction
		
	</div>
	<div class="card-body">
		<div class="table-responsive">
			<table id="datatable-buttons" class="table table-bordered table-sm table-striped w-100">
				<thead>
					<tr class="table_main_row">
						<th>#ID</th>
						<th>Txn Date</th>
						<th>Center Code</th>
						<th>Center Name</th>
						<th>Amount</th>
						<th>Description</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$i=1;
					?>
					<?php $__currentLoopData = $transaction; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($i++); ?></td>
							<td><?php echo e($data->created_at); ?></td>
							<td><?php echo e($data->cl_code); ?></td>
							<td><?php echo e($data->cl_center_name); ?></td>
							<td><?php echo e($data->t_amount); ?> ₹</td>
							<td>Docs fee for <?php echo e($data->t_student_reg_no); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			
		</div>
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('center.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\mayacomputercentre\resources\views/center/view_transaction/index.blade.php ENDPATH**/ ?>
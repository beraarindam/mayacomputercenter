
<?php $__env->startSection('title', 'Mark Attendance'); ?>
<?php $__env->startPush('custom-css'); ?>
<style type="text/css">
	
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-12">
		<div class="page-title-box d-sm-flex align-items-center justify-content-between">
			<h4 class="mb-sm-0 font-size-18">Make Attendance
			<button class='btn btn-primary btn-sm' onClick ='exportxls()'> Export </button></h4>
			<form action ='' method='get'>
				<div class="page-title-right">
					<select name ='batch_id' >
						<option>--Select Btach--</option>
						<?php $__currentLoopData = $batch; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($data->ab_id); ?>" <?php if(request()->get('batch_id') == $data->ab_id): ?> selected <?php endif; ?>><?php echo e($data->ab_name); ?></option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</select>
					<input type='date' class='h6' name='att_date' onblur='submit()'>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- end page title -->
<?php
use Carbon\Carbon;
$date = Carbon::parse(request()->get('att_date'));
$formattedDate = $date->format('d-M-Y (l)');
?>
<?php if(request()->get('batch_id') && request()->get('att_date')): ?>
<form method="post">
			<?php echo csrf_field(); ?>
<div class="card mb-4">
	<div class="card-header bg-secondary text-white font-weight-bold">
		Attendance of <?php echo e($formattedDate); ?> </b>
		
			<button type="submit" class="btn btn-success" style="display: flex; margin:10px">Submit Attendance</button>
		</div>
		<div class="card-body">
			<div class="table-responsive">
				<table id="datatable-buttons" class="table table-bordered table-sm table-striped w-100">
					<thead>
						<tr class="table_main_row">
							
							<th>Roll No</th>
							<th>Student Name</th>
							<?php
								$today = today();
								$dates = [];
								
								for ($i = 1; $i < $today->daysInMonth + 1; ++$i) {
									$dates[] = \Carbon\Carbon::createFromDate($today->year, $today->month, $i)->format('Y-m-d');
								}
							?>
							<?php $__currentLoopData = $dates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<th>
									<?php echo e($date); ?>

								</th>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tr>
					</thead>
					<tbody>
						
						
						
						<?php
							$i=1;
						?>
						<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<input type="hidden" name="student_id" value="<?php echo e($stu->sl_id); ?>">
							<tr>
								<td><?php echo e($stu->sl_reg_no); ?></td>
								<td><?php echo e($stu->sl_name); ?></td>
								<?php for($i = 1; $i < $today->daysInMonth + 1; ++$i): ?>
									<?php
										$date_picker = \Carbon\Carbon::createFromDate($today->year, $today->month, $i)->format('Y-m-d');
										
										$check_attd = \App\Models\center\MarkAttendance::query()
										->where('am_FK_of_student_id', $stu->sl_id)
										->where('am_date', $date_picker)
										->first();
									?>
									<td>
										
										<div class="form-check form-check-inline">
											<input class="form-check-input" id="check_box"
											name="attd[<?php echo e($stu->sl_id); ?>]" type="checkbox" <?php if(isset($check_attd)): ?>  checked <?php endif; ?>
											id="inlineCheckbox1" value="1">
										</div>
									</td>
								<?php endfor; ?>
							</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						
					</tbody>
				</table>
			
		</div>
		
	</div>
</div>
</form>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>
<script type="text/javascript">
	
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('center.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\mayacomputercentre\resources\views/center/attendance/make_attendance.blade.php ENDPATH**/ ?>
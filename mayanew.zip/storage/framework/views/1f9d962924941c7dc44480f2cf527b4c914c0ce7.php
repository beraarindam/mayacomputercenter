
<?php $__env->startSection('title', 'Center'); ?>
<?php $__env->startPush('custom-css'); ?>
	<style type="text/css">
		
	</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header bg-secondary text-white font-weight-bold">
					Center List
					<span class='float-right' style='float:right'>
						<a href="<?php echo e(route('add_center')); ?>">  <button class="btn btn-success btn-sm" > Add New Center</button></a>
				</div>
			<div class="card-body">
				<div class="card-body">
				    <table id="datatable-buttons" class="table table-bordered table-sm table-striped w-100">
				        <thead>
					        <tr class="table_main_row">
					        	<th>Center Code</th>
					            <th>Center Name</th>
					            <th>Director Name</th>
					            <th>Center Address</th>
					            <th>Email</th>
					            <th>Mobile</th>
					            <th>Image</th>
					            <th>Account Status</th>
					            <th>Action</th>
					        </tr>
				        </thead>
				        <tbody>
				        	<?php $i=1; ?>
				        	<?php $__currentLoopData = $center; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				        		<tr>
				        			<td><?php echo e($data->cl_code); ?></td>
				        			<td><?php echo e($data->cl_center_name); ?></td>
				        			<td><?php echo e($data->cl_director_name); ?></td>
				        			<td><?php echo e($data->cl_center_address); ?></td>
				        			<td><?php echo e($data->cl_email); ?></td>
				        			<td><?php echo e($data->cl_mobile); ?></td>
				        			<td>
				        				<img style="width: 47px;" src="<?php echo e(asset('admin/center_image/').'/'.$data->cl_photo); ?>">
				        			</td>
				        			<td>
				        			    <?php echo e($data->cl_account_status); ?>

				        			</td>
				        			<td>
				        			    <select class="mb-1" onchange="centerStatus(<?php echo e($data->cl_code); ?>, this.value);" id="center_status" name="center_status">
				        			        <option value="">--Select--</option>
				        			        <option value="ACTIVE">ACTIVE</option>
				        			        <option value="PENDING">PENDING</option>
				        			    </select>
				        				<a href="<?php echo e(route('edit_center', $data->cl_id)); ?>" class="btn btn-primary btn-sm"><i class="fa-regular fa-eye"></i></a>
				        				<a href="<?php echo e(route('view_center_certificate', $data->cl_id)); ?>" class="btn btn-warning btn-sm"><i class="fa fa-share-square"></i></a>
				        				<a href="<?php echo e(route('delete_center', $data->cl_id)); ?>" class="btn btn-danger btn-sm"><i class="fa fa-trash"></i></a>
				        			</td>
				        		</tr>
				        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>
    <script>
        function centerStatus(center_code, center_status){
        if(center_status == ''){
            alert("Please Select Account Status");
            location.reload();
        }else{
            $.ajax({
    			url: "<?php echo e(route('center.status')); ?>",
    			type: "get",
    			data: {center_code:center_code,center_status:center_status},
    			dataType: "json",
    			success: function(response){
    				if(response.status == 1){
    					alert(response.msg);
    					location.reload();
    				}else{
    				    alert(response.msg);
    				    location.reload();
    				}
    			}
    		});
        }
	    
	}
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\mayacomputercentre\resources\views/admin/center/index.blade.php ENDPATH**/ ?>

<?php $__env->startSection('title', 'Course List'); ?>
<?php $__env->startPush('custom-css'); ?>
	<style type="text/css">
		
	</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row mt-3">
	<div class="col-lg-12">
		<div class="card">
			<div class="card-header bg-secondary text-white font-weight-bold">
					Course List
					<span class='float-right' style='float:right'>
						<a href="<?php echo e(route('add_course')); ?>">  <button class="btn btn-success btn-sm" > Add New Course</button></a>
				</div>
			<div class="card-body">
				<div class="card-body">
				    <table id="datatable-buttons" class="table table-bordered table-sm table-striped w-100">
				        <thead>
					        <tr class="table_main_row">
					        	<th>#ID</th>
					        	<th>Course Name</th>
					            <th>Price</th>
					            <th>Duration</th>
					            <th>Created At</th>
					            <th>Action</th>
					        </tr>
				        </thead>
				        <tbody>
				        	<?php $i=1; ?>
				        	<?php $__currentLoopData = $course; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
				        		<tr>
				        			<td><?php echo e($i++); ?></td>
				        			<td><?php echo e($data->c_full_name); ?>[<?php echo e($data->c_short_name); ?>]</td>
				        			<td><?php echo e($data->c_price); ?></td>
				        			<td><?php echo e($data->c_duration); ?></td>
				        			<td><?php echo e($data->created_at); ?></td>
				        			<td>
				        				<a href="<?php echo e(route('edit_course', $data->c_id)); ?>" class="btn btn-primary btn-sm"><i class="fa-regular fa-eye"></i></a>
				        				<a onclick="return confirm('Are You Sure to delete?');" href="<?php echo e(route('delete_course', $data->c_id)); ?>" class="btn btn-danger btn-sm"><i class="fa-solid fa-trash"></i></a>
				        			</td>
				        		</tr>
				        	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				        </tbody>
				    </table>
				</div>
			</div>
		</div>
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>

<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\mayacomputercentre\resources\views/admin/course/index.blade.php ENDPATH**/ ?>
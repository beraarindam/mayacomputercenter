
<?php $__env->startSection('title', 'Search To Pay'); ?>
<?php $__env->startPush('custom-css'); ?>
<style type="text/css">
	
</style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
	<div class="col-12">
		<div class="page-title-box d-sm-flex align-items-center justify-content-between">
			<h4 class="mb-sm-0 font-size-18">SEARCH TO PAYMENT</h4>
		</div>
	</div>
</div>
<!-- end page title -->
<div class="card mb-4">
	
	<div class="card-body">
		<div class="table-responsive">
			<table id="datatable-buttons" class="table table-bordered table-sm table-striped w-100">
				<thead>
					<tr class="table_main_row">
						<th>Reg.No</th>
						<th>Student Name</th>
						<th>Course</th>
						<th>Total Fee</th>
						<th>Total Paid</th>
						<th>Dues Amount</th>
						<th>Action</th>
					</tr>
				</thead>
				<tbody>
					<?php
						$income = 0;
						$expense = 0;
					?>
					<?php $__currentLoopData = $student; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e($data->sl_reg_no); ?></td>
							<td><?php echo e($data->sl_name); ?></td>
							<td><?php echo e($data->c_short_name); ?></td>
							<td><?php echo e($data->sf_amount); ?></td>
							<td><?php echo e($data->sf_paid); ?></td>
							<td><?php echo e($data->sf_due); ?></td>
							<td>
								<?php if($data->sf_due == 0): ?>
									<a class="btn btn-danger btn-sm">No Dues</a>
								<?php else: ?>
									<a href="<?php echo e(route('fees_payment', ['student_id'=>$data->sf_FK_of_student_id])); ?>" class="btn btn-success btn-sm">Pay Fee</a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</tbody>
			</table>
			
		</div>
		
	</div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('custom-js'); ?>
<script>
	function set_fee(student_id){
		var fees_amount = $('#fees_amount_'+student_id).val();
		$.ajax({
			url: "<?php echo e(route('set_fee_amount')); ?>",
			type: "get",
			data:{student_id,fees_amount},
			dataType: "json",
			success: function(response){
				if(response.status == 1){
					alert(response.msg);
				}
			}
		});
	}
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('center.layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp82\htdocs\mayacomputercentre\resources\views/center/search_to_pay/index.blade.php ENDPATH**/ ?>